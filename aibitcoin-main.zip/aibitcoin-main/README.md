### 월100만원 버는 AI 비트코인 자동매매 만들기 
### https://www.youtube.com/c/코딩강사

실제 거래 서버 링크
http://54.180.95.145:8501/

![Logo](https://github.com/nissi153/aibitcoin/blob/main/res/thumbnail.png)
![Logo](https://github.com/nissi153/aibitcoin/blob/main/res/dashboard.png)
![Logo](https://github.com/nissi153/aibitcoin/blob/main/res/split.png)
![Logo](https://github.com/nissi153/aibitcoin/blob/main/res/배포완료.png)
